$(document).ready(function(){
     
    $('.btnDetails').on('click',function(e){
	let productModal = $('#productModal');
	productModal.modal('show');
	
	let name = $(this).closest('.info').children('.row').children('div').children('#name').text();
	$('.modal-body').find('#name').text(name);

	let image = $(this).closest('.col-item').find('img').attr('src');
	$('.modal-body').find('image').attr('src', image);

	let bintang = $(this).closest('.info').find('#rating').html();
	$('.modal-body').find('#rating').html(bintang);

	let harga = $(this).closest('.info').children('.row').children('div').children('#price').text();
	$('.modal-body').find('#price').text(harga);

	})

$('.btnAdd').on('click',function(e){
	let nama = $(this).closest('.info').children('.row').children('div').children('#name').text();

	let harga = $(this).closest('.info').children('.row').children('div').children('#price').text();

	let bintang = $(this).closest('.info').find('#rating').html();

	let no = '<td>' + (document.getElementById('tableData').rows.length) + '</td>';
	let colName = '<td>' + nama + '</td>';

	let colHarga = '<td>' + harga + '</td>';

	let colBintang = '<td>' + bintang + '</td>';


	let data =  '<tr>' + no + colName + colHarga + colBintang + '</tr>';;
	$('.table').append(data);
})
})