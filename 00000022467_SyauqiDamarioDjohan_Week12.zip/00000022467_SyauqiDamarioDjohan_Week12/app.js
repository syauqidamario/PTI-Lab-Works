let app = angular.module('todoList',[]);

app.controller('todoController', function($scope){
    $scope.newTodo = '';
    $scope.todos = [];
    $scope.addTodo = function(){
        if($scope.newTodo.length == 0){
            alert("Todo must not be empty!");
            return 0;
        }
        if($scope.todos.find(todos => todos.name == $scope.newTodo)){
            alert("Task already in the list!");
            return 0;
        }
        $scope.todos.push({
            name: $scope.newTodo,
            done: false
        })
        $scope.newTodo = '';
        console.log($scope.todos);
    }
    $scope.isEmpty = function(){
        if($scope.todos.length > 0){
            return false
        }
        return true
    }
    $scope.changeStatus = function(todo){
        $scope.todos[$scope.todos.indexOf(todo)].done = !todo.done;
    }
    $scope.delete = function(todo){
        $scope.todos.splice($scope.todos.indexOf(todo),1);
    }
})