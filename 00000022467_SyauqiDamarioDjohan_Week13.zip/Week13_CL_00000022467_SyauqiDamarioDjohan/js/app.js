let app = angular.module("akikStore", ["ngRoute"])

app.config(function($routeProvider, $locationProvider){
	$routeProvider.when('/', {
		templateUrl: 'templates/new-gem.html',
		controller: 'newGemController'
	})
	.when('/gem-list', {
		templateUrl: 'templates/gem-list.html',
		controller: 'gemListController'
	})
	$locationProvider.html5Mode({
		enabled: true,
		requireBase: false
	})
})

app.controller('newGemController', ['$scope', function($s){
	$s.newGem = {}
	$s.addGem = function(){
		console.log($s.newGem.type)
		let existingGems = localStorage.getItem('gems')
		if(existingGems === null){
			existingGems = []
		}
		else{
			existingGems = JSON.parse(existingGems)
		}
		existingGems.push($s.newGem)
		localStorage.setItem('gems', JSON.stringify(existingGems))
		$s.resetForm()
	}
	$s.resetForm = function(){
		$s.newGem.type = ''
		$s.newGem.weight = ''
		$s.newGem.price = ''
		$s.newGem.description = ''
		$s.newGem.contact = ''

		$s.gemForm.$setPristine()
		$s.gemForm.$setUntouched()
	}
}])

app.controller('gemListController', ['$scope', function($s){
	$s.gems = localStorage.getItem('gems');
    $s.gems = JSON.parse($s.gems)
}])

app.directive('singleGem', function(){
	return{
		templateUrl : 'templates/single-gem.html',
		scope:{
			gemData: '='
		}
	}
})
