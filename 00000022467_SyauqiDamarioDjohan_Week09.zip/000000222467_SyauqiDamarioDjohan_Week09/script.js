$(document).ready(function(){
	$("#accordion").accordion({
		collapsible: true
	});
	let dialog = $('#dialog-form').dialog({
		autoOpen: false,
		height: 400,
		widt: 350,
		modal: true,
		buttons: {
			"Add new order": function(){
				if    ($("#inputName").val()=="" || $("#inputDeposit").val()==""){
					alert("Data Incomplete");
				}
				else{
					let roomType;
					if($("#inputHarga").val()==200){
						roomType = "Single";
					}
					else if($("#inputHarga").val()==350){
						roomType = "Double";
					}
					else if($("#inputHarga").val()==600){
						roomType = "Duplex";
					}
					else if($("#inputHarga").val()==1000){
						roomType = "Cabana";
					}

					let addRow = "<tr> <td>" 
								+ $("#inputName").val() 
								+ "</td> <td>" + roomType 
								+ "</td> <td>$"
								+$("#inputDeposit").val()
								+" </td> </tr>";
					$("tbody").append(addRow);
					dialog.dialog("close");
				}
			},
			Cancel: function(){
				dialog.dialog("close");
			}
		},
		close: function(){
			$("form")[0].reset();
		}
	});
	$('.btnAddOrder').on('click', function(btn)
	{
		let price = $(this).parent().attr("id");
		if(price=="single"){
			$("#inputHarga").val("200");
		}
		else if(price=="double"){
			$("#inputHarga").val("350");
		}
		else if(price=="duplex"){
			$("#inputHarga").val("600");
		}
		else if(price=="cabana"){
			$("#inputHarga").val("1000");
		}
		dialog.dialog('open');
	});
});

function renderAllProduct(products, discountFlag){
	products = JSON.parse(JSON.stringify(products))
	if(discountFlag)
		products.map(product => {
			product.price *= 0.75
			return product
		})
	document.getElementById('card-container').innerHTML=''
	product.forEach(product => renderProduct(product))
}